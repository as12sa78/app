from setuptools import setup

setup (
    name='vsearch',
    version='1.0',
    description='Поисковая утилита',
    author='Пишу я с книги',
    author_email='roga_kopyta@gmail.com',
    url='roga_i_kopyta.com',
    py_modules=['vsearch'],
)